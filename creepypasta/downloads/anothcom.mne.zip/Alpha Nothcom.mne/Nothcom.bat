@ECHO OFF
java -Xms512m -Xmx1024m -Djava.library.path="%CD%/natives" -cp "%CD%/natives/Nothcom.jar";"%CD%/natives/jinput.jar";"%CD%/natives/lwjgl.jar";"%CD%/natives/lwjgl_util.jar" net.minecraft.client.Minecraft
cmd /k